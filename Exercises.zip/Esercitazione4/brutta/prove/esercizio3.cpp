#include <iostream>

using namespace std;

double​ ​ S0(vector<​ double​ >& sigma){

};

double​ ​ S1(vector<​ double​ >& V1, vector<​ double​ >& sigma)​ ;
double​ ​ S2(vector<​ double​ >& V1, vector<​ double​ >& V2, vector<​ double​ >&
sigma)​ ;

int main (){

}
