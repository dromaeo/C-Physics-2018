#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
int main(){

//lettura del nome del file
//alternativa con cin:
/* string filename;
 cout << "Inserire il nome del file" << endl;
 cin >> filename;
*/ 
 ifstream ifile;
 ifile.open("temperature.dat");

 if (!ifile.good() ){
   cerr << "Errore nell'apertura del file" << endl;
   return 1;
 }

//inserimento dati nel vettore
 int n;
 ifile >> n;

 int alldaynumb=n;
 int temp_numb=5;

 int daynumb=0;
 int temperatura=0;

 double dati[50];

 for (int k=0; k<50; k++){
   ifile >> dati[k];
   double temperatura= dati[k];
   cout << temperatura << endl;
 }
  ifile.close();



 //output

 return 0;
}
