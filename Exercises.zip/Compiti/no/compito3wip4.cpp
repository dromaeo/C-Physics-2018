#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
int main(){

//lettura del nome del file
/* //alternativa con cin:
   string filename;
   cout << "Inserire il nome del file" << endl;
   cin >> filename;
*/ 
 ifstream ifile;
 ifile.open("temperature.dat");

 if (!ifile.good() ){
   cerr << "Errore nell'apertura del file (temperature.dat)" << endl;
   return 1;
 }
 
 //inserimento dati nel vettore
 int n;
 ifile >> n;

 int alldaynumb=n;
 int temp_numb=5;

 int daynumb=0;
 int temperatura=0;

 vector < vector<double> > matrix;
 for (int daynumb=0; daynumb<alldaynumb; daynumb++){
   vector<double> tmpRow;
    for (int temperatura=0; temperatura<temp_numb; temperatura++){
      double element;
      ifile >> element;
      tmpRow.push_back(element);
    }
    matrix.push_back(tmpRow);
 }

 /*
 //stampa delle temperature
 for (int daynumb=0; daynumb<alldaynumb; daynumb++){
     cout << "Le temperature del giorno " << daynumb+1 << " sono:" <<endl;
   for (int temperatura=0; temperatura<temp_numb; temperatura++){
     cout <<  matrix[daynumb][temperatura] << endl;
   }
 }
 */
 ifile.close();


 //Per ricavare la temperatura massima:
 int cicle=0;
 double tempsum[n]; //somma temporanea
 tempsum[0]=0;
 double sum[n];
 double media[n];

 for (int cicle=0; cicle<n; cicle++) {
   for (int i=0; i<5; i++){
     tempsum[cicle] = tempsum[cicle] + matrix[cicle][i];
   }
   sum[cicle]= tempsum[cicle]; // è la somma delle temperature
                               // per ogni giorno considerato
   media[cicle] = (sum[cicle] / 5);
 }
 
 double hottest=0; // valore della temperatura massima
 int theday; //giorno cercato 
 int otherdays;
 cout <<"Il giorno più caldo è stato il ";
 for (int k=0; k<n; k++){
   if (media[k]> hottest){
     hottest= media[k];
     theday=k;
   }
 }
 cout << theday+1 <<  "° "<< endl;
 cout <<"In tal giorno la media delle temperature era di " << hottest << "°"<< endl;
   
 for (int k=0; k<n; k++){ 
   if (media[k]== hottest) {
     otherdays=k;
     if (otherdays!=theday)
     cout << "La stessa temperatura è stata trovata nel " <<  otherdays+1 << "° giorno " << endl;
   }
 } 
 
 return 0;
}
