#include <iostream>
using namespace std;
int main(){
  int n;
  cout << "Inserire un numero naturale: " << endl;
  cin >> n;

  bool primo;
  int r;
  int i=2;
  while (i<n){
    r = n % i;
    i++;}
  if(r==0) break;
  if(r!=0) continue;}

  if (r==0){
    primo = true;}
  else {
    primo = false;}

  if (primo){
    cout << "Il numero non e` primo" << endl;
      }
  
  else{
    cout << "Il numero e` primo" << endl;
  }
  
   return 0;
}
