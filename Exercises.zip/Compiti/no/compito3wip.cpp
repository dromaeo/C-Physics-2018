#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
int main(){

//lettura del nome del file
//alternativa con cin
/* string filename;
 cout << "Inserire il nome del file" << endl;
 cin >> filename;
*/ 
 ifstream ifile;
 ifile.open("temperature.dat");

 if (!ifile.good() ){
   cerr << "Errore nell'apertura del file" << endl;
   return 1;
 }

 
 //inserimento dati nel vettore
 int n;
 ifile >> n;

 int alldaynumb=n;
 int temp_numb=5;

 int daynumb=0;
 int temperatura=0;

 vector < vector<double> > matrix;
 for (int daynumb=0; daynumb<alldaynumb; daynumb++){
   vector<double> tmpRow;
    for (int temperatura=0; temperatura<temp_numb; temperatura++){
      double element;
      ifile >> element;
      tmpRow.push_back(element);
    }
    matrix.push_back(tmpRow);
 }

 
 for (int daynumb=0; daynumb<alldaynumb; daynumb++){
     cout << "Le temperature del giorno " << daynumb+1 << " sono:" <<endl;
   for (int temperatura=0; temperatura<temp_numb; temperatura++){
     cout <<  matrix[daynumb][temperatura] << endl;
   }
 }

 ifile.close();



 //massima t
 int hottest;
 double hotday= matrix[daynumb][0];
 for (int i=0; i < (n*5); i++) {
   if (matrix[daynumb][i]>hotday){
     hotday= matrix[daynumb][i];
   }
   
 
 
 //output
    cout << "Il giorno piu` caldo e` stato il " << hotday+1 << "° " << endl;

 }
 return 0;
}
