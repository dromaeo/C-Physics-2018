#ifndef _MATRICE_H_
#define _MATRICE_H_

#include <vector>

using namespace std;

class Matrice
{
 public:
   
   Matrice();
   Matrice(int righe, int colonne);
   Matrice(int righe);
   
   /* metodo per l'accesso all'elemento (riga, colonna) della matrice */
   double& operator()(int riga, int colonna);
   /* metodo per l'accesso all'elemento (riga, 0) della matrice */
   double& operator()(int riga) { return operator()(riga, 0); }

   /* prodotto tra matrici */
   Matrice operator*(const Matrice& m);

   /* getter per numero di righe e colonne */
   int  GetNumeroRighe() { return m_nrighe; }
   int  GetNumeroColonne() { return m_ncolonne; } 

   /*
    * risolve il sistema A x = b, dove:
    * - A e' la matrice su cui viene chiamato il metodo
    * - x e' il vettore di incognite
    * - b e' il vettore di termini noti
    */
   Matrice Soluzione(Matrice& b);

   /* Calcolo della matrice inversa */
   Matrice Inversione();

   /* scambia le righe rigaX e rigaY */
   void ScambiaRighe(int rigaX, int rigaY);

   /* esegue riga = riga * val */
   void MoltiplicaRiga(int riga, double val);

   /* esegue rigaX = rigaX + val* rigaY */
   void SommaRighe(int rigaX, int rigaY, double val);

   /* applica il metodo di Gauss-Jordan */
   void GaussJordan();

 private:
   int m_nrighe;
   int m_ncolonne;
   vector< vector<double> > m_matrice;

   void Init(int righe, int colonne);
};
       
ostream& operator<<(ostream& os, Matrice m);

#endif

