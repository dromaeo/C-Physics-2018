#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <cmath>
#include <iomanip>

#define PRECIS 10

using namespace std;

double f(double x) {	// la funzione di cui voglio trovare lo zero
double y;

  y = x*x/2 - 7;
  
  return y;
}
  
int main () {

double a,b,e,m;
int i;

// contatore delle iterazioni
  i = 1;
  
// soglia di errore accettabile
  e = 1.0/1000000000;

// intervallo iniziale di ricerca
  a = 1.0;
  b = 7.0;
  
// punto medio dell'intervallo
  m = (a+b) / 2;
  
  while ( abs(f(m)) > e ) {

// stampo il numero di iterazione in cui ci troviamo
    cout << "passaggio " << i << endl;
    i=i+1;

// descrivo l'intervallo attualmente in esame
    cout << "[a, b] = [";
    cout << setprecision(PRECIS) << a << ", ";
    cout << setprecision(PRECIS) << b << "]" << endl;
    
// stampo ascissa e ordinata della, al momento, miglior soluzione in mio possesso
    cout << "m = " << setprecision(PRECIS) << m << endl;
    cout << "f(m) = " << setprecision(PRECIS) << f(m) << endl;
    cout << endl;
 
 // decido quale mete' dell'intervallo scartare   
    if (f(m)*f(b) > 0)
      b = m;
    else
      a = m;

// calcolo del nuovo punto medio
    m = (a+b) / 2;

/*
    m = a + (b-a)/2;	// formula alternativa
    m = b - (b-a)/2;	// formula alternativa
*/
  }
  
  system("pause");
  return 0;
  
}
