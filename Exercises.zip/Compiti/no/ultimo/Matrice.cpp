#include <iostream>
#include <cmath>
#include "Matrice.h"

Matrice::Matrice()
{
   Init(0, 0);
}


Matrice::Matrice(int righe, int colonne)
{
   Init(righe, colonne);   
}


Matrice::Matrice(int righe)
{
   Init(righe, 1);
}


void Matrice::Init(int righe, int colonne)
{
   m_nrighe  = righe;
   m_ncolonne  = colonne;
  
   m_matrice.resize(m_nrighe);
   for (int i = 0; i < (int)m_matrice.size(); i++)
      m_matrice[i].resize(m_ncolonne);
}


double& Matrice::operator()(int riga, int colonna)
{  
   return m_matrice[riga][colonna];
}


Matrice Matrice::operator*(const Matrice& m)
{
   Matrice risultato(m_nrighe, m.m_ncolonne);
   for (int row = 0; row < m_nrighe; row++)
   { 
      for (int mCol = 0; mCol < m.m_ncolonne; mCol++)
      {
	 double sum=0;
	 for (int col = 0; col < m_ncolonne; col++)
	    sum += m_matrice[row][col] * m.m_matrice[col][mCol];

	 risultato(row, mCol) = sum;
      }
   }
   return risultato;
}


ostream& operator<<(ostream& os, Matrice m)
{
   os.setf(ios::fixed,ios::floatfield); 
   for (int i=0;i<m.GetNumeroRighe();i++)
   {
      for (int j=0;j<m.GetNumeroColonne();j++)
	 os << m(i,j) << " ";
      os << endl;
   }
   return os;  
}


Matrice Matrice::Soluzione(Matrice& b){

  // Risolve A x = b

  //Controllo che b sia un vettore
  if (b.GetNumeroColonne() != 1)
    cerr << "Il numero di colonne dovrebbe essere 1" << endl;

  Matrice x(b);

  //Create Matrice (A,B)
  Matrice m(m_nrighe, m_ncolonne + 1);
  for (int i = 0; i < m_nrighe; i++)
  {
     for (int j = 0; j <= m_ncolonne; j++)
     {
	if (j == m_ncolonne)
	   m(i, m_ncolonne) = b(i, 0);
	else
	   m(i, j) = m_matrice[i][j];
     }
  }
  
  m.GaussJordan();

  //Prendo x dall'ultima colonna di mat
  for (int row = 0; row < m_nrighe; row++)
     x(row, 0) = m(row, m_ncolonne);
  
  return x;

}



Matrice Matrice::Inversione()
{
  //Calcola l'inversa di A

  //Creo matrice con le stesse dimensioni della matrice corrente
  Matrice inversa(m_nrighe, m_ncolonne);
  
  //Creo la matrice (A, I)
  Matrice m(m_nrighe, 2 * m_ncolonne);

  for (int riga = 0; riga < m_nrighe; riga++)
  {
     for (int colonna = 0; colonna < m_ncolonne; colonna++)
     {
	m(riga, colonna) = m_matrice[riga][colonna];

	if(riga == colonna)
	   m(riga, colonna + m_ncolonne) = 1;
	else
	   m(riga, colonna + m_ncolonne) = 0;
     }
  }

  //cout << m << endl;
  m.GaussJordan();
  //cout << m << endl;
  
  // Riempimento matrice inversa 
  for (int row = 0; row < m_nrighe; row++)
  {
     for (int col = 0; col < m_ncolonne; col++)
	inversa(row, col) = m(row, col + m_ncolonne);
  }

  return inversa;
}




//---------------------------------------------------------
// Metodi da implementare (vedere spiegazioni nel file .h)
//---------------------------------------------------------

void Matrice::ScambiaRighe(int rigaX, int rigaY)
{
}

void Matrice::MoltiplicaRiga(int riga, double val)
{ 
}


void Matrice::SommaRighe(int rigaX, int rigaY, double val)
{
}



void Matrice::GaussJordan()
{  
  for (int k = 0; k < m_nrighe; k++)
  {     
     // Se a_kk == 0, cerca una riga i per cui a_ik !=0
     // e alla prima che trova scambia la riga k con la i

     // Moltiplica la riga k per 1/a_kk
     
     // Somma a tutte le righe, esclusa la riga k,
     // la riga k moltiplicata per -a_ik
  }
}
