#include <iostream>
#include <fstream>
#include "Matrice.h"

using namespace std;
  
int main()
{
   // 1) leggere il file sistlin10.dat, contenetene i coefficienti di un sistema
   //    di equazioni lineari con 10 incognite, e cercare le soluzioni con il
   //    metodo di Gauss-Jordan (metodo Soluzione() della classe Matrice).
   //    Formato del file sistlin10.dat:
   //    - La prima riga del file contiene il numero n di variabili del sistema
   //    - seguono n righe, ciascuna composta da n + 1 elementi: gli n
   //      coefficienti delle equazioni e il termine noto (ultimo elemento
   //      di ogni riga)

   // 2) leggere il file magic9.dat, contenente una matrice 9x9, e calcolare
   //    l'inversa della matrice data usando il metodo Inversa() della classe
   //    Matrice. Stampare su terminale:
   //    - la matrice letta
   //    - la matrice inversa
   //    - il prodotto delle due matrici precedenti
   return 0;
}
