{
  cout << "inserire f" << endl;
  string fstr;
  cin >> fstr;
  TF2 f("f", fstr.c_str());
  double x, y, dx, dy;
  cout << "inserire x, y, dx e dy" << endl;
  cin >> x >> y >> dx >> dy;

  double q= f.Eval (x,y);

  double f1= f.Eval(x+dx,y);
  double f2= f.Eval(x-dx,y);
  double dfx= (f1-f2)*0.5;

  double f3= f.Eval(x,y+dy);
  double f4= f.Eval(x,y-dy);
  double dfy_t= (f3-f4)*0.5;
  double dfy;
  if (dfy>0)
    dfy= dfy_t;
  else
    dfy= -dfy_t;
  
  cout << "dfx " <<dfx<<" dfy" << dfy<<endl;

  double dq= dfx + dfy;

  cout << "Il risultato è " << q << " +- " << dq << endl;
}
