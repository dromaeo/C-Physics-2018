#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
int main(){

//lettura del nome del file
/* string filename;
 cout << "Inserire il nome del file" << endl;
 cin >> filename;
*/ 
 ifstream ifile;
 ifile.open("temperature.dat");

 if (!ifile.good() ){
   cerr << "Errore nell'apertura del file" << endl;
   return 1;
 }

 
 //inserimento dati nel vettore
 int n;
 ifile >> n;

 int alldaynumb=n+1;
 int temp_numb=5;

 vector < vector<double> > matrix;
 for (int daynumb=1; daynumb<alldaynumb; daynumb++){
   vector<double> tmpRow;
    for (int temperatura=0; temperatura<temp_numb; temperatura++){
      double element;
      ifile >> element;
      tmpRow.push_back(element);
    }
    matrix.push_back(tmpRow);
 }

 for (int daynumb=0; daynumb<alldaynumb; daynumb++){
   for (int temperatura=0; temperatura<temp_numb; temperatura++)
     cout << matrix[daynumb][temperatura] << endl;
 }



 ifile.close();



 /*
 //categorizzazione dati

 for (int daynumb=1; ciclo<5; i+5){
daynumb= ciclo 
  }


 //output

 if (i<=5){
   cout << "Il giorno piu` caldo e` stato il " << hotday << "° " << endl;
 }

 */



 //endl
 return 0;
}
