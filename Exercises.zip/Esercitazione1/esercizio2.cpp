#include <iostream>
using namespace std;
int main() {
   double lato,area; 
   cout << "Dammi il lato del quadrato" << endl;
   cin >> lato; 
   area = lato*lato; 
   cout << "L'area vale: " << area << endl;
   return 0;
}
