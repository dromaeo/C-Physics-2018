#include <iostream> 
using namespace std; 
int main() {
   double base,altezza; 
   cout << "Dammi la base e l'altezza del rettangolo" << endl; 
   cin >> base >> altezza; 
   cout << "L'area vale: " << base*altezza << endl; 
   return 0;
}
